<?php
include_once '../lib/curl.php';
include_once '../lib/functions.php';
if(isset($_GET['url'])){
	$url = $_GET['url'];
	$key = $_GET['key'];
	$server = explode('|', server($url));
	$json = array(
		'status' => '0',
		'yourip' => getUserIP(),
		'data'	=> ''
	);
	if($server[0] == 'Facebook'){
		$data = file_get_contents('../data/facebook.txt');
		if(preg_match('#'.$key.'\|(.+?)$#m', $data,$mat)){
			$info = explode('|', $mat[0]);
			//$json['status'] = 1;
			$check = $server[0]($url,$info[2],$info[1]);
			if($check['status'] == 'success'){
				$json['status'] = 1;
				$json['data'] = $check['data'];
			}
			//echo json_encode($json);
		}
		else{
			//echo json_encode($json);
		}
		
	}
	else{

	}
	echo json_encode($json);
}

function server($link){
	$server = '';
	if(strpos($link, 'facebook.com')){
		$server .= 'Facebook|'.include_once '../inc/facebook.php';
	}
	return $server;
}