<?php
//include_once '../lib/curl.php';
function Facebook($link,$t,$c){
    $args = array(
        'status' => 'error',
        'data' => array()
    );
    if(preg_match('#videos#', $link)){
        preg_match('#videos\/(.+?)\/#', $link,$mat);
    }
    else{
        preg_match('#com\/(.*)#', $link, $mat);
    }
    $id = $mat[1];
	$check = get_fbid($id,$t);
    if($check['status'] == 'error')
        return $args;
	$fbid = $check['fbid'];
	$url = 'https://www.facebook.com/story.php?story_fbid='.$id.'&id='.$fbid;
	$get = curl_facebook($url,$c);
	$checksd = preg_match('#sd_src_no_ratelimit\:"(.+?)"#',$get,$sd);
    $checkhd = preg_match('#hd_src_no_ratelimit\:"(.+?)"#',$get,$hd);
    if($checksd == false && $checkhd == false){
        return $args;
    }
    $json = array(
        '360' => $sd[1],
        '720' => $hd[1]
    );
	krsort($json);
    $args['status'] = 'success';
    $args['data'] = $json;
    return $args;
}
//print_r(Facebook('https://www.facebook.com/closeupvn.page/videos/591601467874585/','EAAAAUaZA8jlABAGeJqtEvANxixVTAemj2ZAZA88haB67BAfnGK2AaxV8W2ZCK9sejKfcpq5oH6EobPdQEPT9kZAZBqf1UZA590E7tnJZCnV0WpbBPX5gLGDDD8eft0KUOkpCaJqH71OiwDbFXboX0IkkOPDNGpPaqqO96HZByeevm7QZDZD','c_user=100015503167473;xs=50:H9N7S24dowgoxg:2:1524290377:18952:8885;fr=0y94cBnw9wS5R2Nag.AWVMw33Q9t-xev7B8oR8A2R5-k4.Ba2tOB..AAA.0.0.Ba2tOB.AWVsNi0p;datr=gdPaWlxw5v3HU9E85uljQYZ0;'));
function get_fbid($videoid,$token){
	$url = 'https://graph.facebook.com/'.$videoid.'?fields=from&access_token='.$token;
	$get = curl($url);
	$json = json_decode($get,true);
	if(isset($json['from']['id'])){
		return array('status'=>'success','fbid'=>$json['from']['id']);
	}
	else{
		return array('status'=>'error');
	}
}

function curl_facebook($Url,$c){
    $ch = @curl_init();
    curl_setopt($ch, CURLOPT_URL, $Url);
    curl_setopt($ch, CURLOPT_REFERER, "https://www.facebook.com");
    curl_setopt($ch, CURLOPT_USERAGENT, "Mozilla");
    curl_setopt($ch, CURLOPT_HTTPHEADER, array("Cookie: ".$c));
    curl_setopt($ch, CURLOPT_HEADER, 1);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_TIMEOUT, 10);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, FALSE);
    curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 2);
    $output = curl_exec($ch);
    curl_close($ch);
    return $output;
}