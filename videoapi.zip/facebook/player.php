<?php
	$key = $_GET['key'];
	$link = $_GET['link'];
	$url = 'http://videoapi.test:81/api?url='.$link.'&key='.$key;
	$get = file_get_contents($url);
	$json = json_decode($get);
	if($json->status == 1){
		$sources = '';
		foreach ($json->data as $key => $value) {
			$sources .= '{file:"'.$value.'", label:"'.$key.'p", type:"video/mp4"},';
		}
		$sources = '['.rtrim($sources,',').']';
	}
	
?>

<!DOCTYPE HTML>
<html>
	<head>
		<title>
			JW Player Reponsive Video
		</title>
		<script src="/assets/js/jwplayer.js"></script>
		</script>
		<style type="text/css">
			html, body {
				height: 100%;
				width: 100%;
				padding: 0;
				margin: 0;
			}
			#player {
				height: 100%;
				width: 100%; 
				padding: 0;
			}
		</style>
	</head>
	<body>
	<div id="player">
	</div>
		<script type="text/javascript">
			jwplayer("player").setup({
				height: "100%",
				width: "100%",
				stretching: "exactfit",
				sources: <?php echo $sources; ?>
			});
		</script>
	</body>
</html>
<?php ?>