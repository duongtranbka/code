<?php include_once('../layouts/header.php'); ?>
<!-- Page Content -->
<div id="page-wrapper">
        <div class="row">
            <div class="col-lg-12">
                <h1 class="page-header">Tạo key mã hóa</h1>
            </div>
            <!-- /.col-lg-12 -->
        </div>
        <!-- /.row -->
        <div class="row">
        	<div class="col-lg-8">
                <div class="panel panel-info">
                    <div class="panel-heading">
                        Tạo key mã hóa để get video private
                    </div>
                    <div class="panel-body">
                        <div class="form-group input-group">
                            <span class="input-group-addon"><i class="fa fa-gears"></i> Access Token</span>
                            <input id="txt_token" type="text" class="form-control" placeholder="Nhập access token">
                            <div class="input-group-btn">
	                            <button id="generate-key" class="btn btn-primary" type="button">
	                                <i class="fa fa-refresh"></i> Get Key
	                            </button>
	                        </div>
                        </div>
                        <div class="form-group input-group">  
                            <span class="input-group-addon"><i class="fa fa-key"></i> Key mã hóa</span>
                            <input id="txt_key" type="text" class="form-control" placeholder="Key xuất hiện ở đây">
                        </div>
                        <p class="text-warning pull-right">Lưu ý: Không nên tạo key nhiều lần. Nếu không tạo được key, thử cách lấy token tại đây <a href="/facebook/generate_token.php" target="_blank">Click here</a></p>
                    </div>
                </div>
        	</div>
        </div>

        <div class="row">
            <div class="col-lg-8">
                <div class="panel panel-info">
                    <div class="panel-heading">
                        Hướng dẫn lấy access token facebook
                    </div>
                    <div class="panel-body">
                        <p><strong>Bước 1:</strong> Đăng nhập facebook và vào trang cá nhân.<br><strong>Bước 2:</strong> View-source (Ctrl + U) và tìm kiếm (Ctrl + F) từ khóa: <strong>"EAAA"</strong> bạn sẽ thấy access token.</p>
                        <img src="/assets/images/huongdan.png" style="width: 100%; height: auto" />
                    </div>
                </div>
            </div>
        </div>

</div>
<!-- /#page-wrapper -->
<?php include_once('../layouts/footer.php'); ?>
<script type="text/javascript">
    $("#generate-key").click(function(){
        var token = $('#txt_token').val().trim();
        if(token == ""){
            alert('Bạn chưa nhập token!');
        }else{
            $('#generate-key').html('<i class="fa fa-refresh fa-spin"></i> Getting');
            $.ajax({
                url: '/facebook/generate.php',
                type: 'post',
                dataType: 'json',
                data: {
                    token: token
                },
                success: function(data){
                    if(data.status == 'success')
                        $('#txt_key').val(data.key);
                    else
                        alert('Không thể tạo key');
                    $('#generate-key').html('<i class="fa fa-refresh"></i> Get Key');
                }
            });
        }
    });
</script>